package de.letsbuildacompiler.compiler;

import java.util.HashMap;
import java.util.Map;

import de.letsbuildacompiler.compiler.exceptions.ExcecaoVariavelJaDeclarada;
import de.letsbuildacompiler.compiler.exceptions.ExcecaoVariavelNaoDeclarada;
import de.letsbuildacompiler.parser.GramaticaBaseVisitor;
import de.letsbuildacompiler.parser.GramaticaParser.AtribContext;
import de.letsbuildacompiler.parser.GramaticaParser.DivisaoContext;
import de.letsbuildacompiler.parser.GramaticaParser.MenorContext;
import de.letsbuildacompiler.parser.GramaticaParser.MetoddeclContext;
import de.letsbuildacompiler.parser.GramaticaParser.ModuloContext;
import de.letsbuildacompiler.parser.GramaticaParser.MultiplicacaoContext;
import de.letsbuildacompiler.parser.GramaticaParser.NumeroInteiroContext;
import de.letsbuildacompiler.parser.GramaticaParser.PrintlnContext;
import de.letsbuildacompiler.parser.GramaticaParser.SomaContext;
import de.letsbuildacompiler.parser.GramaticaParser.SubtracaoContext;
import de.letsbuildacompiler.parser.GramaticaParser.VardeclContext;
/*
import de.letsbuildacompiler.parser.GramaticaParser.AssignmentContext;
import de.letsbuildacompiler.parser.GramaticaParser.DivContext;
import de.letsbuildacompiler.parser.GramaticaParser.MinusContext;
import de.letsbuildacompiler.parser.GramaticaParser.MultContext;
import de.letsbuildacompiler.parser.GramaticaParser.NumberContext;
import de.letsbuildacompiler.parser.GramaticaParser.PlusContext;
import de.letsbuildacompiler.parser.GramaticaParser.PrintlnContext;
import de.letsbuildacompiler.parser.GramaticaParser.VarDeclarationContext;
import de.letsbuildacompiler.parser.GramaticaParser.VariableContext;
*/
public class MyVisitor extends GramaticaBaseVisitor<String>{
	//mapa que conterá variaveis declaradas que serão usadas na table do jasmin.
	private Map<String, Integer> variaveis = new HashMap<>();
	
			
	
	@Override
	public String visitVardecl(VardeclContext ctx) {
		String var = ctx.varName.getText();
		if(variaveis.containsKey(var)){
			throw new ExcecaoVariavelJaDeclarada(ctx.varName);
		}else{
			variaveis.put(var, variaveis.size());
		}
		
//		return super.visitVardecl(ctx);
		return "";
	}
	@Override
	public String visitAtrib(AtribContext ctx) {
		String var = ctx.lvalue().varAtribName.getText();
		if(!variaveis.containsKey(var)){
			throw new ExcecaoVariavelNaoDeclarada(ctx.lvalue().varAtribName);
			
		}
		return visit(ctx.exp)+"\n"+"istore "+variaveis.get(var);
		
	}/*
	@Override
	public String visitMetoddecl(MetoddeclContext ctx) {
		System.out.println("ola "+ctx.escopo.com.retV.getText()+"\n");
		
		return ".method public static "+ctx.nomeFunc.getText()+"()I\n"+
				"	.limit stack 100\n" + 
				"	.limit locals 100\n" + 
				"\n" +  
				
				visit(ctx.escopo.com.retorno()) + "\n" +
				"ireturn\n" +
				".end method";
		
		
	}*/
	
	
	@Override
	public String visitPrintln(PrintlnContext ctx) {
		return "	getstatic java/lang/System/out Ljava/io/PrintStream;\n" + 
				visit(ctx.argument) + "\n" + 
				"	invokevirtual java/io/PrintStream/println(I)V\n";
	}
	////////////////////////////////////////expressao///////////////////////////////////////
	/*
	@Override
	public String visitMenor(MenorContext ctx) {
		//verificar tipo
		String resposta;
		
		System.out.println(ctx.esquerda.getText());
		System.out.println(ctx.direita.getText());
		
		if(Double.valueOf(ctx.esquerda.getText()) < Double.valueOf(ctx.direita.getText()))
			resposta = "true";
		else
			resposta ="false";
		resposta = "\n"+resposta;
		System.out.println(resposta);
		//visitChildren(ctx);
			return "true";
	}
	*/
	////////////////////////////////////////term///////////////////////////////////////////	
	@Override
	public String visitDivisao(DivisaoContext ctx) {
		return visitChildren(ctx) + "\n" +
				"idiv";
	}
	
	@Override
	public String visitMultiplicacao(MultiplicacaoContext ctx) {
		return visitChildren(ctx) + "\n" +
				"imul";
	}
	
	@Override
	public String visitModulo(ModuloContext ctx) {
		return visitChildren(ctx) + "\n" +
				"irem";
	}
	
	@Override
	public String visitSubtracao(SubtracaoContext ctx) {
		return visitChildren(ctx) + "\n" +
				"isub";
	}
	
	@Override
	public String visitSoma(SomaContext ctx) {
		return visitChildren(ctx) + "\n" +
				"iadd";
	}
	////////////////////////////////////////factor///////////////////////////////////////////
	@Override
	public String visitNumeroInteiro(NumeroInteiroContext ctx) {
		return "ldc "+ctx.numero.getText();
	}
	/////////////////////////////////////////////////////////////////////////////////////////
		
	@Override
	protected String aggregateResult(String aggregate, String nextResult) {
		if(aggregate == null){
			return nextResult;
		}
		if(nextResult == null){
			return aggregate;
		}
		return aggregate + "\n" + nextResult;
	}
	
	
/*
@Override
public String visitVarDeclaration(VarDeclarationContext ctx) {
	variables.put(ctx.varName.getText(), variables.size());
	return "";
}

@Override
public String visitAssignment(AssignmentContext ctx) {
	return visit(ctx.expr)+ "\n" +
			"istore "+ variables.get(ctx.varName.getText());
	
}

@Override
public String visitVariable(VariableContext ctx) {
	return "iload "+ variables.get(ctx.varName.getText());
}

@Override
public String visitDiv(DivContext ctx) {
	return visitChildren(ctx) + "\n" +
			"idiv";
}

@Override
public String visitMult(MultContext ctx) {
	return visitChildren(ctx) + "\n" +
			"imul";
}

@Override
public String visitPlus(PlusContext ctx) {
	return visitChildren(ctx) + "\n" +
			"iadd";
}

@Override
public String visitMinus(MinusContext ctx) {
	return visitChildren(ctx) + "\n" +
			"isub";
}

@Override
public String visitNumber(NumberContext ctx) {
	return "ldc "+ctx.number.getText();
}
*/
}